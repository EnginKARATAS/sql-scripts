create procedure PerGetir(@adi varchar(15))
as
select * from Personel where Ad=@adi

exec PerGetir 'maral'


create procedure AdGetir
as
select Ad from Personel p1 inner join Danisman d1 on p1.SicilNo=d1.SicilNo

exec AdGetir


create procedure Toplaa(@sayi1 int, @sayi2 int, @toplam int output)
as
set @toplam=@sayi1+@sayi2

declare @t int
exec Toplaa 3,10,@t output
print @t


create function cevirbuyuk(@soyadlari varchar(50))
returns varchar(50)
as
begin
return upper(@soyadlari) 
end


select dbo.cevirbuyuk(soyad) from Personel


create function TipSayi(@girilentip int)
returns int
begin
declare @sayi int
select @sayi=count(PersonelTipi) from Personel where PersonelTipi=@girilentip
return @sayi
end

select dbo.TipSayi('6')





create function PerTip (@girilentip int)
returns table
as
return(select * from Personel where PersonelTipi> @girilentip)

select Ad,Soyad from dbo.PerTip(3)




Create trigger Ekleme
on Personel
After insert
as
begin
select 'Yeni Personel Eklendi'
end

insert into Personel values(201,11111111111,'Beyza Nur','Cam',1,05555,2)

create trigger GuncelleSay
on Personel
After update
as
begin
update Tabsayac set sayac=sayac+1
end

update Personel set PersonelTipi=2 where Ad='Beyza Nur'


create trigger silEksilt
on Personel
After Delete
as
begin
update Tabsayac set sayac=sayac-1
end

delete from Personel where Ad='Beyza Nur'


