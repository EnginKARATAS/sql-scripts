--1.Store Procedure
CREATE PROCEDURE sp_personelSoyadinaG�reAra
@soyad NVARCHAR(100)
AS
BEGIN
SELECT * FROM Personel  WHERE Soyad LIKE '%'+@soyad+'%'
END

EXEC sp_personelSoyadinaG�reAra 'av'

--2.Store Procedure
CREATE PROCEDURE sp_sirketAdSorgulama
@ad NVARCHAR(100) 
AS
if EXISTS (SELECT * FROM Sirket where Ad=@ad)
print 'Bu isme ait �irket bulunmaktad�r'
else
print 'Bu isme ait �irket bulunmamaktad�r'

EXEC sp_sirketAdSorgulama 'ar�elik';

--3.Store Procedure
CREATE PROCEDURE sp_CheckTc 
@id NVARCHAR(100)
AS
BEGIN
SELECT * FROM Personel WHERE Tc=@id
END

EXEC sp_CheckTc 21186367618

--1.Function
CREATE FUNCTION fn_personelTipListeleID(@tipID int)
RETURNS TABLE
AS
RETURN (SELECT * FROM PersonelTip WHERE Tip_ID=@tipID)

select * from dbo.fn_personelTipListeleID(1)

--2.Function
CREATE FUNCTION FnPersonelTipeG�rePersonelSayisi(@tipno int)  
RETURNS INT  
AS  
BEGIN  
DECLARE @personelsayisi INT  
SET @personelsayisi = (Select Count(*) as PersonelSayisi from Personel where PersonelTipi = @tipno)
RETURN @personelSayisi 
END


select dbo.FnPersonelTipeG�rePersonelSayisi(2)

--3.Functions
CREATE FUNCTION Fn_personelAdinaG�reKa�PersonelOldugu(@ad nvarchar(100))
RETURNS TABLE
AS
RETURN (select Ad, count(*) as PersonelSayisi from Personel where Ad = @ad group by Ad)


select * from dbo.Fn_personelAdinaG�reKa�PersonelOldugu('melike')

--1.Trigger
CREATE TRIGGER trgadresEkle
ON Adres
AFTER INSERT
AS
BEGIN
SET NOCOUNT ON;
SELECT 'Yeni Adres eklendi'
SET NOCOUNT OFF;
END

INSERT INTO Adres (SicilNo,IlceID) VALUES (101798,10)

--2.Trigger
CREATE TRIGGER trgpersonelSilindiktenSonraListeleme
ON Personel
AFTER DELETE
AS
BEGIN
SELECT * FROM Personel
END

DELETE FROM Personel WHERE SicilNo=3

--3.Trigger
CREATE TRIGGER trgPersonelGuncelleme
ON Personel
AFTER UPDATE
AS
DECLARE @SicilNo int
DECLARE @Ad nvarchar(50)
BEGIN
SELECT @SicilNo=SicilNo, @Ad=Ad from inserted 
UPDATE Personel set Ad=@ad where SicilNo=@sicilno
END
