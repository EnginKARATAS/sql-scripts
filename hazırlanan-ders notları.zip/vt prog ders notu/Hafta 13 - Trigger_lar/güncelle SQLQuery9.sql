Create TRIGGER trg_PersonelGuncelle
ON Personel
AFTER UPDATE
AS
BEGIN

declare @islem nvarchar(max)

declare @E_Per_ID int
declare @E_SicilNo int
declare @E_Tc nvarchar(max)
declare @E_Ad nvarchar(50)
declare @E_Soyad nvarchar(50)
declare @E_PersonelTipi int
declare @E_Telefon nvarchar(max)
declare @E_Prim decimal(18,5)

declare @Y_Per_ID int
declare @Y_SicilNo int
declare @Y_Tc nvarchar(max)
declare @Y_Ad nvarchar(50)
declare @Y_Soyad nvarchar(50)
declare @Y_PersonelTipi int
declare @Y_Telefon nvarchar(max)
declare @Y_Prim decimal(18,5)

select
@E_Per_ID = Per_ID,
@E_SicilNo = SicilNo, 
@E_Tc = Tc,
@E_Ad = Ad,
@E_Soyad = Soyad,
@E_PersonelTipi = PersonelTipi,
@E_Telefon = Telefon,
@E_Prim = Prim from deleted

select 
@Y_Per_ID = Per_ID,
@Y_SicilNo = SicilNo, 
@Y_Tc = Tc,
@Y_Ad = Ad,
@Y_Soyad = Soyad,
@Y_PersonelTipi = PersonelTipi,
@Y_Telefon = Telefon,
@Y_Prim = Prim from inserted

set @islem = '';

set @islem += 'Per_ID='+CAST(@E_Per_ID as nvarchar)+'->'+CAST(@Y_Per_ID as nvarchar)+'||'

if(@E_SicilNo != @Y_SicilNo)
begin
set @islem += 'SicilNo='+cast(@E_SicilNo as nvarchar)+'->'+cast(@Y_SicilNo as nvarchar)+'||'
end

if(@E_Tc != @Y_Tc)
begin
set @islem += 'Tc='+cast(@E_Tc as nvarchar)+'->'+cast(@Y_Tc as nvarchar)+'||'
end

if(@E_Ad != @Y_Ad)
begin
set @islem += 'Ad='+cast(@E_Ad as nvarchar)+'->'+cast(@Y_Ad as nvarchar)+'||'
end

if(@E_Soyad != @Y_Soyad)
begin
set @islem += 'Soyad='+cast(@E_Soyad as nvarchar)+'->'+cast(@Y_Soyad as nvarchar)+'||'
end

if(@E_PersonelTipi != @Y_PersonelTipi)
begin
set @islem += 'PersonelTipi='+cast(@E_PersonelTipi as nvarchar)+'->'+cast(@Y_PersonelTipi as nvarchar)+'||'
end

if(@E_Telefon != @Y_Telefon)
begin
set @islem += 'Telefon='+cast(@E_Telefon as nvarchar)+'->'+cast(@Y_Telefon as nvarchar)+'||'
end

if(@E_Prim != @Y_Prim)
begin
set @islem += 'Prim='+cast(@E_Prim as nvarchar)+'->'+cast(@Y_Prim as nvarchar)+'||'
end

insert into Log(log_type,log_tarih,log_table_name,islem)
VALUES (
'U',
GETDATE(),
'Personel', @islem)
END;
