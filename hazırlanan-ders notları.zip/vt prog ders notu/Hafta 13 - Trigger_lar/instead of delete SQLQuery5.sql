create trigger trg_Instead_Personel_Sil
on Personel
instead of Delete
as
begin
	raiserror('Silme i�lemi yap�lamaz',16,1);
	rollback
end

delete from Personel where SicilNo=112