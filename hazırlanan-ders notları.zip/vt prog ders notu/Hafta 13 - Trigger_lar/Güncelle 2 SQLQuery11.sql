Create TRIGGER trg_PersonelGuncelle2
ON Personel
AFTER UPDATE
AS
BEGIN
declare @islem nvarchar(max)

set @islem = ''

if(UPDATE(Ad))
begin
set @islem += 'Ad degisti||';
end

if(UPDATE(Soyad))
begin
set @islem += 'Soyad degisti||';
end

/*
T�m s�tunlar dahil edilebilir..
*/
insert into Log(log_type,log_tarih,log_table_name,islem)
VALUES (
'U',
GETDATE(),
'Personel', @islem)

END;