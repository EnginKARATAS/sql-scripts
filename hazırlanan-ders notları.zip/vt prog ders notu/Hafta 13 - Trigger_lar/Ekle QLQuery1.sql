Create TRIGGER trg_Personel_Insert_Log
ON Personel
AFTER INSERT
AS
BEGIN 
--select * from Personel
declare @SicilNo int
declare @Tc nvarchar(max)
declare @Ad nvarchar(50)
declare @Soyad nvarchar(50)
declare @PersonelTipi int
declare @Telefon nvarchar(max)
declare @Prim decimal(18,5)
--Create Database db;
select 
@SicilNo = SicilNo, 
@Tc = Tc,
@Ad = Ad,
@Soyad = Soyad,
@PersonelTipi = PersonelTipi,
@Telefon = Telefon,
@Prim = Prim from inserted

insert into Log(log_type,log_tarih,log_table_name,islem)
VALUES (
'I',
GETDATE(),
'Personel', 
'SicilNo='+cast(@SicilNo as nvarchar)+'||
TC='+cast(@Tc as nvarchar)+'||
Ad='+cast(@Ad as nvarchar)+'||
Soyad='+cast(@Soyad as nvarchar)+'||
PersonelTipi='+cast(@PersonelTipi as nvarchar)+'||
Telefon='+cast(@Telefon as nvarchar)+'||
Prim='+cast(@Prim as nvarchar)+'')
END;

insert into Personel VALUES (966,'99999999999', 'Test Trigger', 'Denemesi', 1, '5556556666',1)