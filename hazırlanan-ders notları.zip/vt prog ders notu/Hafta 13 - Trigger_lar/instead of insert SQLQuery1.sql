create trigger trg_Instead_Personel_Ekle
on Personel
Instead Of Insert
as
begin

Declare @PersonelTipi_ int
Select @PersonelTipi_ = PersonelTipi from inserted
if(@PersonelTipi_ > 6)
	begin
		rollback
		RAISERROR('ge�erli personel tipi giriniz', 16, 1)
	end
	else
	begin
		declare @SicilNo int
		declare @Tc nvarchar(max)
		declare @Ad nvarchar(50)
		declare @Soyad nvarchar(50)
		declare @PersonelTipi int
		declare @Telefon nvarchar(max)
		declare @Prim decimal(18,5)
		select 
		@SicilNo = SicilNo, 
		@Tc = Tc,
		@Ad = Ad,
		@Soyad = Soyad,
		@PersonelTipi = PersonelTipi,
		@Telefon = Telefon,
		@Prim = Prim from inserted
		insert into Personel(SicilNo,Tc,Ad,Soyad,PersonelTipi,Telefon,Prim)
		Values(@SicilNo,@Tc,@Ad,@Soyad,@PersonelTipi,@Telefon,@Prim)
	end
end;

insert into Personel(SicilNo,Tc,Ad,Soyad,PersonelTipi,Telefon,Prim)
Values (111001,22233344412,'test metni','test2',40,'5444433233',1)

select * from Personel where Ad like '%test%'

select COUNT(1) from Personel