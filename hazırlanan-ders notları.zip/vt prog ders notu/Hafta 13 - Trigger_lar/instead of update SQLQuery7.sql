CREATE TRIGGER trg_Instead_Personel_Guncelle
ON Personel
INSTEAD OF UPDATE
AS
BEGIN
		declare @Per_ID int
		declare @SicilNo int
		declare @Tc nvarchar(max)
		declare @Ad nvarchar(50)
		declare @Soyad nvarchar(50)
		declare @PersonelTipi int
		declare @Telefon nvarchar(max)
		declare @Prim decimal(18,5)

       select
		@Per_ID = Per_ID, 
		@SicilNo = SicilNo, 
		@Tc = Tc,
		@Ad = Ad,
		@Soyad = Soyad,
		@PersonelTipi = PersonelTipi,
		@Telefon = Telefon,
		@Prim = Prim from inserted
 
       IF UPDATE(Tc)
       BEGIN
              RAISERROR('Tc Alan� G�ncellenemez.', 16 ,1)
              ROLLBACK
       END
       ELSE
       BEGIN
              UPDATE Personel set
			  SicilNo=@SicilNo,
			  Ad = @Ad,
			  Soyad = @Soyad,
			  PersonelTipi = @PersonelTipi,
			  Telefon = @Telefon,
			  Prim = @Prim
			  WHERE Per_ID = @Per_ID
       END
END

select * from Personel where SicilNo=100
update Personel set Ad = 'ay�e 4', Tc=96654569874 Where SicilNo=100